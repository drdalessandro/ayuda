# EPA Bienestar - WhatsApp Orchestrator

## Chatbot de Evaluación Cardiovascular → Medplum FHIR R4

Este proyecto implementa el chatbot de WhatsApp que evalúa la salud cardiovascular
de mujeres usando Life's Essential 8 (AHA) + MEPA-Express, y almacena los resultados
como recursos FHIR R4 en Medplum.

### Estructura del proyecto

```
epa-whatsapp-orchestrator/
├── src/
│   ├── index.ts           ← Entry point: webhook handler
│   ├── session.ts         ← DynamoDB session management
│   ├── state-machine.ts   ← Conversation flow (19 states)
│   ├── questions.ts       ← Life Stage + MEPA + LE8 data
│   ├── whatsapp.ts        ← WhatsApp Business API sender
│   └── fhir-builder.ts    ← FHIR Bundle builder + Medplum auth
├── scripts/
│   └── setup-aws.sh       ← One-click AWS infrastructure setup
├── package.json
├── tsconfig.json
└── README.md
```

### Recursos FHIR generados por sesión

| # | Recurso | Cantidad | Condición |
|---|---------|----------|-----------|
| 1 | Patient (epa-patient) | 1 | Siempre |
| 2 | QuestionnaireResponse (MEPA) | 1 | Siempre |
| 3 | Observation (MEPA score) | 1 | Siempre |
| 4-10 | Observation (LE8 x7) | 7 | Siempre |
| 11 | RiskAssessment | 1 | Siempre |
| 12 | ServiceRequest | 0-1 | Si hay brechas |
| **Total** | | **11-12** | |

### Quick Start

```bash
# 1. Editar scripts/setup-aws.sh con tu ACCOUNT_ID y REGION
# 2. Ejecutar:
chmod +x scripts/setup-aws.sh
./scripts/setup-aws.sh

# 3. Actualizar secrets y env vars (ver output del script)
# 4. Enviar "hola" a tu número de WhatsApp Business
```

### Variables de entorno requeridas

| Variable | Dónde obtenerla |
|----------|----------------|
| `DYNAMODB_TABLE` | setup-aws.sh la crea |
| `MEDPLUM_BASE_URL` | Tu instancia Medplum |
| `MEDPLUM_SECRETS_ARN` | AWS Secrets Manager ARN |
| `WA_VERIFY_TOKEN` | String random que vos elegís |
| `WA_APP_SECRET` | Meta Business Suite > App > Settings |
| `WA_PHONE_NUMBER_ID` | Meta Business Suite > WhatsApp > Phone |
| `WA_ACCESS_TOKEN` | Meta Business Suite > System User token |
