#!/bin/bash
# ============================================================
# EPA Bienestar - AWS Setup Script
# Run this from your local machine with AWS CLI configured
# 
# Prerequisites:
#   - AWS CLI v2 installed and configured (aws configure)
#   - Node.js 20+ installed
#   - Your AWS account ID (replace YOUR_ACCOUNT_ID below)
# ============================================================

set -e

# ── CONFIGURATION (edit these!) ──
REGION="us-east-1"            # Change to your region (or sa-east-1 for São Paulo)
ACCOUNT_ID="YOUR_ACCOUNT_ID" # Your AWS account ID (12 digits)
FUNCTION_NAME="epa-whatsapp-orchestrator"
TABLE_NAME="epa-wa-sessions"
API_NAME="epa-whatsapp-api"

echo "============================================"
echo "EPA Bienestar - AWS Infrastructure Setup"
echo "============================================"

# ── STEP 1: Create DynamoDB Table ──
echo ""
echo "STEP 1: Creating DynamoDB table..."
aws dynamodb create-table \
  --table-name $TABLE_NAME \
  --attribute-definitions \
    AttributeName=phone,AttributeType=S \
  --key-schema \
    AttributeName=phone,KeyType=HASH \
  --billing-mode PAY_PER_REQUEST \
  --region $REGION \
  --tags Key=project,Value=epa-bienestar \
  2>/dev/null && echo "  ✅ Table created: $TABLE_NAME" || echo "  ⚠️  Table already exists"

# Enable TTL (auto-delete expired sessions)
aws dynamodb update-time-to-live \
  --table-name $TABLE_NAME \
  --time-to-live-specification "Enabled=true,AttributeName=expiresAt" \
  --region $REGION \
  2>/dev/null && echo "  ✅ TTL enabled on expiresAt" || echo "  ⚠️  TTL already configured"

# ── STEP 2: Create Secrets in AWS Secrets Manager ──
echo ""
echo "STEP 2: Creating secrets..."
echo "  ℹ️  You will need to UPDATE these values after configuring Medplum and WhatsApp"

aws secretsmanager create-secret \
  --name epa-medplum-credentials \
  --description "Medplum ClientApplication credentials for EPA chatbot" \
  --secret-string '{"clientId":"REPLACE_ME","clientSecret":"REPLACE_ME"}' \
  --region $REGION \
  2>/dev/null && echo "  ✅ Secret created: epa-medplum-credentials" || echo "  ⚠️  Secret already exists"

echo "  📝 NOTE: Update this secret later with your actual Medplum credentials:"
echo "     aws secretsmanager update-secret --secret-id epa-medplum-credentials \\"
echo "       --secret-string '{\"clientId\":\"YOUR_ID\",\"clientSecret\":\"YOUR_SECRET\"}'"

# ── STEP 3: Create IAM Role for Lambda ──
echo ""
echo "STEP 3: Creating IAM role..."

TRUST_POLICY='{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Principal": {"Service": "lambda.amazonaws.com"},
    "Action": "sts:AssumeRole"
  }]
}'

aws iam create-role \
  --role-name epa-whatsapp-lambda-role \
  --assume-role-policy-document "$TRUST_POLICY" \
  --region $REGION \
  2>/dev/null && echo "  ✅ IAM role created" || echo "  ⚠️  Role already exists"

# Attach policies
aws iam attach-role-policy \
  --role-name epa-whatsapp-lambda-role \
  --policy-arn arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole \
  2>/dev/null

# Custom policy for DynamoDB + Secrets Manager
POLICY_DOC="{
  \"Version\": \"2012-10-17\",
  \"Statement\": [
    {
      \"Effect\": \"Allow\",
      \"Action\": [\"dynamodb:GetItem\",\"dynamodb:PutItem\",\"dynamodb:UpdateItem\",\"dynamodb:DeleteItem\"],
      \"Resource\": \"arn:aws:dynamodb:${REGION}:${ACCOUNT_ID}:table/${TABLE_NAME}\"
    },
    {
      \"Effect\": \"Allow\",
      \"Action\": [\"secretsmanager:GetSecretValue\"],
      \"Resource\": \"arn:aws:secretsmanager:${REGION}:${ACCOUNT_ID}:secret:epa-medplum-credentials*\"
    }
  ]
}"

aws iam put-role-policy \
  --role-name epa-whatsapp-lambda-role \
  --policy-name epa-chatbot-access \
  --policy-document "$POLICY_DOC" \
  2>/dev/null && echo "  ✅ Custom policy attached" || echo "  ⚠️  Policy already exists"

echo "  ⏳ Waiting 10 seconds for IAM role propagation..."
sleep 10

# ── STEP 4: Build and Package Lambda ──
echo ""
echo "STEP 4: Building Lambda package..."
cd "$(dirname "$0")/.."
npm install
npm run build
cd dist && zip -r ../lambda-package.zip . && cd ..
zip -ur lambda-package.zip node_modules/
echo "  ✅ Package built: lambda-package.zip"

# ── STEP 5: Create Lambda Function ──
echo ""
echo "STEP 5: Creating Lambda function..."

SECRETS_ARN=$(aws secretsmanager describe-secret \
  --secret-id epa-medplum-credentials \
  --query 'ARN' --output text \
  --region $REGION)

aws lambda create-function \
  --function-name $FUNCTION_NAME \
  --runtime nodejs20.x \
  --role "arn:aws:iam::${ACCOUNT_ID}:role/epa-whatsapp-lambda-role" \
  --handler index.handler \
  --zip-file fileb://lambda-package.zip \
  --timeout 30 \
  --memory-size 512 \
  --environment "Variables={
    DYNAMODB_TABLE=${TABLE_NAME},
    MEDPLUM_BASE_URL=https://api.epa-bienestar.com.ar,
    MEDPLUM_SECRETS_ARN=${SECRETS_ARN},
    WA_VERIFY_TOKEN=REPLACE_WITH_YOUR_VERIFY_TOKEN,
    WA_APP_SECRET=REPLACE_WITH_YOUR_APP_SECRET,
    WA_PHONE_NUMBER_ID=REPLACE_WITH_YOUR_PHONE_ID,
    WA_ACCESS_TOKEN=REPLACE_WITH_YOUR_WA_TOKEN
  }" \
  --region $REGION \
  2>/dev/null && echo "  ✅ Lambda created: $FUNCTION_NAME" || echo "  ⚠️  Lambda already exists, updating..."

# Update if exists
aws lambda update-function-code \
  --function-name $FUNCTION_NAME \
  --zip-file fileb://lambda-package.zip \
  --region $REGION \
  2>/dev/null

# ── STEP 6: Create API Gateway ──
echo ""
echo "STEP 6: Creating API Gateway..."

API_ID=$(aws apigateway create-rest-api \
  --name $API_NAME \
  --description "EPA Bienestar WhatsApp Webhook" \
  --endpoint-configuration types=REGIONAL \
  --query 'id' --output text \
  --region $REGION \
  2>/dev/null) && echo "  ✅ API created: $API_ID" || echo "  ⚠️  Check API Gateway manually"

if [ ! -z "$API_ID" ]; then
  # Get root resource ID
  ROOT_ID=$(aws apigateway get-resources \
    --rest-api-id $API_ID \
    --query 'items[0].id' --output text \
    --region $REGION)

  # Create /webhook resource
  RESOURCE_ID=$(aws apigateway create-resource \
    --rest-api-id $API_ID \
    --parent-id $ROOT_ID \
    --path-part webhook \
    --query 'id' --output text \
    --region $REGION)

  # Create GET method (for Meta verification)
  aws apigateway put-method \
    --rest-api-id $API_ID \
    --resource-id $RESOURCE_ID \
    --http-method GET \
    --authorization-type NONE \
    --region $REGION 2>/dev/null

  # Create POST method (for messages)
  aws apigateway put-method \
    --rest-api-id $API_ID \
    --resource-id $RESOURCE_ID \
    --http-method POST \
    --authorization-type NONE \
    --region $REGION 2>/dev/null

  LAMBDA_ARN="arn:aws:lambda:${REGION}:${ACCOUNT_ID}:function:${FUNCTION_NAME}"

  # Link GET to Lambda
  aws apigateway put-integration \
    --rest-api-id $API_ID \
    --resource-id $RESOURCE_ID \
    --http-method GET \
    --type AWS_PROXY \
    --integration-http-method POST \
    --uri "arn:aws:apigateway:${REGION}:lambda:path/2015-03-31/functions/${LAMBDA_ARN}/invocations" \
    --region $REGION 2>/dev/null

  # Link POST to Lambda
  aws apigateway put-integration \
    --rest-api-id $API_ID \
    --resource-id $RESOURCE_ID \
    --http-method POST \
    --type AWS_PROXY \
    --integration-http-method POST \
    --uri "arn:aws:apigateway:${REGION}:lambda:path/2015-03-31/functions/${LAMBDA_ARN}/invocations" \
    --region $REGION 2>/dev/null

  # Grant API Gateway permission to invoke Lambda
  aws lambda add-permission \
    --function-name $FUNCTION_NAME \
    --statement-id apigateway-invoke \
    --action lambda:InvokeFunction \
    --principal apigateway.amazonaws.com \
    --source-arn "arn:aws:execute-api:${REGION}:${ACCOUNT_ID}:${API_ID}/*" \
    --region $REGION 2>/dev/null

  # Deploy API
  aws apigateway create-deployment \
    --rest-api-id $API_ID \
    --stage-name prod \
    --region $REGION 2>/dev/null

  WEBHOOK_URL="https://${API_ID}.execute-api.${REGION}.amazonaws.com/prod/webhook"
  echo "  ✅ API deployed!"
  echo ""
  echo "  ╔══════════════════════════════════════════════════╗"
  echo "  ║  YOUR WEBHOOK URL:                               ║"
  echo "  ║  $WEBHOOK_URL  ║"
  echo "  ╚══════════════════════════════════════════════════╝"
  echo ""
  echo "  📝 Use this URL in Meta WhatsApp Business API → Webhook configuration"
fi

echo ""
echo "============================================"
echo "Setup complete! Next steps:"
echo "============================================"
echo ""
echo "1. UPDATE Medplum credentials:"
echo "   aws secretsmanager update-secret --secret-id epa-medplum-credentials \\"
echo "     --secret-string '{\"clientId\":\"YOUR_MEDPLUM_CLIENT_ID\",\"clientSecret\":\"YOUR_SECRET\"}'"
echo ""
echo "2. UPDATE Lambda environment variables with WhatsApp credentials:"
echo "   aws lambda update-function-configuration \\"
echo "     --function-name $FUNCTION_NAME \\"
echo "     --environment 'Variables={...your actual tokens...}'"
echo ""
echo "3. CONFIGURE Meta WhatsApp Business API webhook:"
echo "   URL: $WEBHOOK_URL"
echo "   Verify Token: (the one you set in WA_VERIFY_TOKEN env var)"
echo "   Subscribed fields: messages"
echo ""
echo "4. TEST: Send 'hola' to your WhatsApp Business number!"
echo ""
