// ============================================================
// FHIR R4 Bundle Builder + Medplum Submission
// Builds all resources and sends as transaction Bundle
// ============================================================

import { MedplumClient } from '@medplum/core';
import { Session } from './session';
import { MEPA_ITEMS, LE8_METRICS, LIFE_STAGE_WEIGHTS } from './questions';
import { SecretsManagerClient, GetSecretValueCommand } from '@aws-sdk/client-secrets-manager';

// ── Medplum Client (cached for Lambda warm starts) ──
let medplum: MedplumClient | null = null;
let cachedSecrets: { clientId: string; clientSecret: string } | null = null;

const MEDPLUM_BASE_URL = process.env.MEDPLUM_BASE_URL || 'https://api.epa-bienestar.com.ar';
const SECRETS_ARN = process.env.MEDPLUM_SECRETS_ARN!;

async function getSecrets(): Promise<{ clientId: string; clientSecret: string }> {
  if (cachedSecrets) return cachedSecrets;

  const sm = new SecretsManagerClient({ region: process.env.AWS_REGION });
  const result = await sm.send(new GetSecretValueCommand({ SecretId: SECRETS_ARN }));
  cachedSecrets = JSON.parse(result.SecretString!);
  return cachedSecrets!;
}

async function getMedplumClient(): Promise<MedplumClient> {
  if (medplum) return medplum;

  const secrets = await getSecrets();
  medplum = new MedplumClient({
    baseUrl: MEDPLUM_BASE_URL,
    fetch: fetch,
  });

  await medplum.startClientLogin(secrets.clientId, secrets.clientSecret);
  return medplum;
}

// ── Build and Submit FHIR Bundle ──
export async function submitToMedplum(session: Session): Promise<any> {
  const client = await getMedplumClient();
  const bundle = buildBundle(session);

  console.log(`Submitting Bundle with ${bundle.entry.length} entries for ${session.phone}`);
  const result = await client.executeBatch(bundle);
  console.log('Medplum response:', JSON.stringify(result).slice(0, 500));

  return result;
}

// ── Build Complete FHIR Bundle ──
function buildBundle(session: Session): any {
  const now = new Date().toISOString();
  const group = session.lifeStage?.group || 'A';
  const entries: any[] = [];

  // ── 1. Patient Resource ──
  const patientUuid = 'urn:uuid:patient-' + session.phone;
  entries.push({
    fullUrl: patientUuid,
    resource: {
      resourceType: 'Patient',
      meta: {
        profile: ['https://epa-bienestar.com.ar/fhir/StructureDefinition/epa-patient']
      },
      extension: [
        {
          url: 'https://epa-bienestar.com.ar/fhir/StructureDefinition/life-stage',
          valueCoding: {
            system: 'https://epa-bienestar.com.ar/CodeSystem/life-stage',
            code: `group-${group.toLowerCase()}`,
            display: getGroupDisplay(group)
          }
        },
        {
          url: 'https://epa-bienestar.com.ar/fhir/StructureDefinition/acquisition-channel',
          valueString: 'whatsapp-chatbot'
        },
        ...(session.lifeStage?.contextTag ? [{
          url: 'https://epa-bienestar.com.ar/fhir/StructureDefinition/context-tag',
          valueString: session.lifeStage.contextTag
        }] : [])
      ],
      active: true,
      gender: 'female',
      name: session.userName ? [{ given: [session.userName] }] : undefined,
      telecom: [{
        system: 'phone',
        value: '+' + session.phone,
        use: 'mobile'
      }]
    },
    request: { method: 'POST', url: 'Patient' }
  });

  // ── 2. MEPA-Express QuestionnaireResponse ──
  if (session.mepaExpress && session.mepaExpress.answers.length > 0) {
    const qrUuid = 'urn:uuid:qr-mepa-' + session.phone;
    entries.push({
      fullUrl: qrUuid,
      resource: {
        resourceType: 'QuestionnaireResponse',
        status: 'completed',
        questionnaire: 'https://epa-bienestar.com.ar/Questionnaire/mepa-express-8',
        subject: { reference: patientUuid },
        authored: now,
        item: session.mepaExpress.answers.map((a, i) => ({
          linkId: `mepa-express-${i + 1}`,
          text: MEPA_ITEMS[i]?.question || `Item ${i + 1}`,
          answer: [{
            valueCoding: {
              system: 'https://epa-bienestar.com.ar/CodeSystem/mepa-express-frequency',
              code: `freq-${a.chosenValue}`,
              display: MEPA_ITEMS[i]?.options[a.chosenValue]?.title || ''
            }
          }]
        })),
        extension: [
          {
            url: 'https://epa-bienestar.com.ar/StructureDefinition/mepa-express-total-score',
            valueInteger: session.mepaExpress.totalScore || 0
          },
          {
            url: 'https://epa-bienestar.com.ar/StructureDefinition/cvh-diet-points',
            valueInteger: session.mepaExpress.cvhDietPoints || 0
          }
        ]
      },
      request: { method: 'POST', url: 'QuestionnaireResponse' }
    });

    // ── 3. Diet Observation (from MEPA) ──
    entries.push({
      fullUrl: 'urn:uuid:obs-diet-' + session.phone,
      resource: {
        resourceType: 'Observation',
        status: 'final',
        subject: { reference: patientUuid },
        effectiveDateTime: now,
        category: [{ coding: [{ system: 'http://terminology.hl7.org/CodeSystem/observation-category', code: 'survey' }] }],
        code: {
          coding: [{ system: 'http://loinc.org', code: '99697-2', display: 'Diet quality score' }],
          text: 'MEPA-Express Diet Quality Score'
        },
        valueQuantity: {
          value: session.mepaExpress.totalScore || 0,
          unit: 'points',
          system: 'http://unitsofmeasure.org',
          code: '{score}'
        },
        component: session.mepaExpress.answers.map((a, i) => ({
          code: {
            coding: [{
              system: 'https://epa-bienestar.com.ar/CodeSystem/mepa-express',
              code: MEPA_ITEMS[i]?.id || `item-${i}`,
              display: MEPA_ITEMS[i]?.name || ''
            }]
          },
          valueBoolean: a.score === 1
        }))
      },
      request: { method: 'POST', url: 'Observation' }
    });
  }

  // ── 4-10. LE8 Observations (7 metrics) ──
  const gaps: { loinc: string; display: string; name: string }[] = [];

  if (session.le8Quick && session.le8Quick.answers.length > 0) {
    session.le8Quick.answers.forEach((a, i) => {
      const metric = LE8_METRICS[i];
      if (!metric) return;

      const obs: any = {
        resourceType: 'Observation',
        status: a.isUnknown ? 'preliminary' : 'final',
        subject: { reference: patientUuid },
        effectiveDateTime: now,
        category: [{ coding: [{ system: 'http://terminology.hl7.org/CodeSystem/observation-category', code: metric.category }] }],
        code: {
          coding: [{ system: 'http://loinc.org', code: metric.loinc, display: metric.loincDisplay }],
          text: metric.name
        },
        extension: [{
          url: 'https://epa-bienestar.com.ar/StructureDefinition/life-stage-weight',
          valueDecimal: LIFE_STAGE_WEIGHTS[group]?.[metric.id] || 1
        }]
      };

      if (a.isUnknown) {
        obs.dataAbsentReason = {
          coding: [{
            system: 'http://terminology.hl7.org/CodeSystem/data-absent-reason',
            code: 'asked-unknown',
            display: 'Asked but unknown - clinical gap'
          }]
        };
        gaps.push({ loinc: metric.loinc, display: metric.loincDisplay, name: metric.name });
      } else {
        obs.valueQuantity = {
          value: a.points,
          unit: 'CVH points',
          system: 'http://unitsofmeasure.org',
          code: '{score}'
        };
      }

      entries.push({
        fullUrl: `urn:uuid:obs-${metric.id}-${session.phone}`,
        resource: obs,
        request: { method: 'POST', url: 'Observation' }
      });
    });
  }

  // ── 11. RiskAssessment ──
  const score = session.le8Quick?.compositeScore || 0;
  const gapCount = session.le8Quick?.gapCount || 0;
  const cvhLevel = score >= 80 ? 'high' : score >= 50 ? 'moderate' : 'low';

  entries.push({
    fullUrl: 'urn:uuid:ra-' + session.phone,
    resource: {
      resourceType: 'RiskAssessment',
      status: 'final',
      subject: { reference: patientUuid },
      occurrenceDateTime: now,
      code: {
        coding: [{
          system: 'https://epa-bienestar.com.ar/CodeSystem/assessment-type',
          code: 'le8-quick',
          display: 'LE8 Quick WhatsApp Assessment'
        }]
      },
      prediction: [{
        qualitativeRisk: {
          coding: [{
            system: 'https://epa-bienestar.com.ar/CodeSystem/cvh-level',
            code: cvhLevel,
            display: `CVH: ${cvhLevel.charAt(0).toUpperCase() + cvhLevel.slice(1)}`
          }]
        },
        probabilityDecimal: score / 100
      }],
      extension: [
        { url: 'https://epa-bienestar.com.ar/StructureDefinition/le8-composite-score', valueInteger: score },
        { url: 'https://epa-bienestar.com.ar/StructureDefinition/clinical-gaps-count', valueInteger: gapCount },
        { url: 'https://epa-bienestar.com.ar/StructureDefinition/life-stage-group', valueCode: `group-${group.toLowerCase()}` },
        { url: 'https://epa-bienestar.com.ar/StructureDefinition/metrics-available-count', valueInteger: 8 - gapCount },
      ]
    },
    request: { method: 'POST', url: 'RiskAssessment' }
  });

  // ── 12. ServiceRequest (if clinical gaps) ──
  if (gaps.length > 0) {
    entries.push({
      fullUrl: 'urn:uuid:sr-' + session.phone,
      resource: {
        resourceType: 'ServiceRequest',
        status: 'active',
        intent: 'proposal',
        priority: score < 50 ? 'urgent' : 'routine',
        subject: { reference: patientUuid },
        code: { text: 'Estudios cardiovasculares sugeridos - brechas LE8' },
        orderDetail: gaps.map(g => ({
          coding: [{ system: 'http://loinc.org', code: g.loinc, display: g.display }]
        })),
        note: [{
          text: `Paciente Grupo ${group} no conoce: ${gaps.map(g => g.name).join(', ')}. ` +
                `Evaluación LE8 Quick vía WhatsApp. Score parcial: ${score}/100.`
        }]
      },
      request: { method: 'POST', url: 'ServiceRequest' }
    });
  }

  return {
    resourceType: 'Bundle',
    type: 'transaction',
    entry: entries,
  };
}

function getGroupDisplay(group: string): string {
  const displays: Record<string, string> = {
    A: 'Personal growth and professional development',
    B: 'Planning or experiencing motherhood',
    C: 'Menopause transition and professional plenitude',
    D: 'Active aging, wisdom, and entrepreneurship',
  };
  return displays[group] || displays['A'];
}
