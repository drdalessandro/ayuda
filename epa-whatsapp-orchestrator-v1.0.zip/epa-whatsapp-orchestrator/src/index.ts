// ============================================================
// EPA Bienestar - WhatsApp Orchestrator Lambda
// Entry point: receives Meta webhook, routes to state machine
// ============================================================

import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
import { getSession, saveSession, Session } from './session';
import { processState } from './state-machine';
import { sendWhatsAppMessage } from './whatsapp';
import crypto from 'crypto';

// ── Environment variables (set in Lambda configuration) ──
const WA_VERIFY_TOKEN = process.env.WA_VERIFY_TOKEN!;
const WA_APP_SECRET = process.env.WA_APP_SECRET!;

// ── Main Handler ──
export async function handler(event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult> {
  try {
    // ── GET = Meta webhook verification (only happens once during setup) ──
    if (event.httpMethod === 'GET') {
      return handleVerification(event);
    }

    // ── POST = incoming WhatsApp message ──
    if (event.httpMethod === 'POST') {
      // Step 1: Verify Meta signature (security)
      if (!verifySignature(event)) {
        console.error('Invalid signature - rejecting request');
        return { statusCode: 401, body: 'Invalid signature' };
      }

      // Step 2: Parse the incoming message
      const body = JSON.parse(event.body || '{}');
      const message = extractMessage(body);

      if (!message) {
        // Not a user message (could be a status update) - acknowledge
        return { statusCode: 200, body: 'OK' };
      }

      // Step 3: Get or create session from DynamoDB
      const session = await getSession(message.phone);

      // Step 4: Process through state machine
      const responses = await processState(session, message);

      // Step 5: Send responses back via WhatsApp
      for (const response of responses) {
        await sendWhatsAppMessage(message.phone, response);
        // Small delay between messages for natural feel
        await sleep(500);
      }

      // Step 6: Save updated session
      await saveSession(session);

      return { statusCode: 200, body: 'OK' };
    }

    return { statusCode: 405, body: 'Method not allowed' };

  } catch (error) {
    console.error('Handler error:', error);
    return { statusCode: 200, body: 'OK' }; // Always 200 to Meta
  }
}

// ── Webhook Verification (Meta sends GET to verify your endpoint) ──
function handleVerification(event: APIGatewayProxyEvent): APIGatewayProxyResult {
  const params = event.queryStringParameters || {};
  const mode = params['hub.mode'];
  const token = params['hub.verify_token'];
  const challenge = params['hub.challenge'];

  if (mode === 'subscribe' && token === WA_VERIFY_TOKEN) {
    console.log('Webhook verified successfully');
    return { statusCode: 200, body: challenge || '' };
  }

  return { statusCode: 403, body: 'Verification failed' };
}

// ── Signature Verification (validates request comes from Meta) ──
function verifySignature(event: APIGatewayProxyEvent): boolean {
  const signature = event.headers['x-hub-signature-256'] || event.headers['X-Hub-Signature-256'];
  if (!signature) return false;

  const body = event.body || '';
  const expected = 'sha256=' + crypto
    .createHmac('sha256', WA_APP_SECRET)
    .update(body)
    .digest('hex');

  return crypto.timingSafeEqual(
    Buffer.from(signature),
    Buffer.from(expected)
  );
}

// ── Extract user message from Meta webhook payload ──
function extractMessage(body: any): { phone: string; text: string; buttonId?: string } | null {
  try {
    const entry = body.entry?.[0];
    const changes = entry?.changes?.[0];
    const value = changes?.value;
    const messages = value?.messages;

    if (!messages || messages.length === 0) return null;

    const msg = messages[0];
    const phone = msg.from; // Phone number like "5491112345678"

    // Interactive button reply (our primary input method)
    if (msg.type === 'interactive') {
      const buttonReply = msg.interactive?.button_reply;
      const listReply = msg.interactive?.list_reply;
      return {
        phone,
        text: buttonReply?.title || listReply?.title || '',
        buttonId: buttonReply?.id || listReply?.id || ''
      };
    }

    // Plain text message (for initial "hola" or free text)
    if (msg.type === 'text') {
      return { phone, text: msg.text?.body || '' };
    }

    return null;
  } catch {
    return null;
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}
