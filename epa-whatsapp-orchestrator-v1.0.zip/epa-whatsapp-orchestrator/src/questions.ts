// ============================================================
// Questions Data - Life Stage + MEPA-Express + LE8 Quick
// All questions, scoring criteria, and LOINC mappings
// ============================================================

// ── LIFE STAGE QUESTIONS ──

export const LIFE_STAGE_Q1 = {
  body: '¿En qué rango de edad estás?',
  buttons: [
    { id: 'age_18-27', title: '18 a 27 años' },
    { id: 'age_28-44', title: '28 a 44 años' },
    { id: 'age_45-65', title: '45 a 65 años' },
  ]
};

// Extra button for 66+ (WhatsApp max 3 buttons, so we use list for 4 options)
export const LIFE_STAGE_Q1_LIST = {
  body: 'Primero, contame: ¿en qué rango de edad estás?',
  buttonText: 'Elegir edad',
  sections: [{
    title: 'Rango de edad',
    rows: [
      { id: 'age_18-27', title: '18 a 27 años' },
      { id: 'age_28-44', title: '28 a 44 años' },
      { id: 'age_45-65', title: '45 a 65 años' },
      { id: 'age_66+', title: '66 años o más' },
    ]
  }]
};

export const LIFE_STAGE_Q2: Record<string, {
  body: string;
  buttons: { id: string; title: string }[];
}> = {
  '18-27': {
    body: '¿Qué describe mejor tu momento actual?',
    buttons: [
      { id: 'ctx_student', title: 'Estudiando / recién recibida' },
      { id: 'ctx_career', title: 'Arrancando mi carrera' },
      { id: 'ctx_personal', title: 'Desarrollo personal' },
    ]
  },
  '28-44': {
    body: '¿Cuál de estas opciones describe mejor tu situación?',
    buttons: [
      { id: 'ctx_planning', title: 'Planificando ser mamá' },
      { id: 'ctx_pregnant', title: 'Embarazada / mamá reciente' },
      { id: 'ctx_career28', title: 'Enfocada en mi carrera' },
    ]
  },
  '45-65': {
    body: '¿Qué describe mejor tu momento?',
    buttons: [
      { id: 'ctx_menopause', title: 'Cambios hormonales' },
      { id: 'ctx_empty_nest', title: 'Hijos adultos' },
      { id: 'ctx_late_mother', title: 'Maternidad tardía' },
    ]
  },
  '66+': {
    body: '¿Qué te motiva hoy?',
    buttons: [
      { id: 'ctx_active', title: 'Mantenerme activa' },
      { id: 'ctx_grandma', title: 'Disfrutar con mis nietos' },
      { id: 'ctx_entrepreneur', title: 'Viajando y emprendiendo' },
    ]
  }
};

// Mapping: context → group
export function resolveGroup(ageRange: string, contextId: string): 'A' | 'B' | 'C' | 'D' {
  if (ageRange === '18-27') return 'A';
  if (ageRange === '66+') return 'D';
  if (ageRange === '28-44') {
    if (contextId === 'ctx_planning' || contextId === 'ctx_pregnant') return 'B';
    return 'A'; // Career-focused 28-44 → Group A
  }
  if (ageRange === '45-65') {
    if (contextId === 'ctx_late_mother') return 'B'; // Late maternity → Group B
    return 'C';
  }
  return 'A';
}

export const GROUP_MESSAGES: Record<string, { welcome: string; focus: string }> = {
  A: {
    welcome: 'Tu corazón joven es tu mejor inversión. Vamos a establecer hábitos que te acompañen toda la vida.',
    focus: 'Foco: nutrición + actividad física + sueño'
  },
  B: {
    welcome: 'Tu corazón prepara el camino para una nueva vida. Cada métrica que optimicemos hoy protege a dos.',
    focus: 'Foco: glucosa + nicotina + apoyo reproductivo'
  },
  C: {
    welcome: 'Tu cuerpo está cambiando, y tu corazón necesita atención especial. Juntas vamos a transitar esta etapa.',
    focus: 'Foco: lípidos + presión arterial + monitoreo CV'
  },
  D: {
    welcome: 'Cada latido cuenta una historia de sabiduría. Tu experiencia de vida es tu fortaleza.',
    focus: 'Foco: presión arterial + peso + prevención secundaria'
  },
};

// ── MEPA-EXPRESS 8 ITEMS ──

export interface MEPAItem {
  id: string;
  name: string;
  question: string;
  direction: 'positive' | 'inverse';
  options: { id: string; title: string; score: number }[];
}

export const MEPA_ITEMS: MEPAItem[] = [
  {
    id: 'olive_oil', name: 'Aceite de oliva',
    question: '¿Usás aceite de oliva para cocinar o como aderezo?',
    direction: 'positive',
    options: [
      { id: 'mepa1_a', title: 'Todos los días', score: 1 },
      { id: 'mepa1_b', title: 'Algunas veces/semana', score: 0 },
      { id: 'mepa1_c', title: 'Casi nunca', score: 0 },
    ]
  },
  {
    id: 'vegetables', name: 'Verduras',
    question: '¿Cuántas porciones de verduras comés por día?',
    direction: 'positive',
    options: [
      { id: 'mepa2_a', title: '3 o más por día', score: 1 },
      { id: 'mepa2_b', title: '1 a 2 por día', score: 0 },
      { id: 'mepa2_c', title: 'Menos de 1 por día', score: 0 },
    ]
  },
  {
    id: 'fruits', name: 'Frutas y bayas',
    question: '¿Comés frutas frescas o bayas (arándanos, frutillas)?',
    direction: 'positive',
    options: [
      { id: 'mepa3_a', title: 'Todos los días, variadas', score: 1 },
      { id: 'mepa3_b', title: 'Algunas veces/semana', score: 0 },
      { id: 'mepa3_c', title: 'Rara vez', score: 0 },
    ]
  },
  {
    id: 'fish', name: 'Pescado',
    question: '¿Cuántas veces por semana comés pescado (no frito)?',
    direction: 'positive',
    options: [
      { id: 'mepa4_a', title: '2 o más veces/semana', score: 1 },
      { id: 'mepa4_b', title: '1 vez por semana', score: 1 },
      { id: 'mepa4_c', title: 'Menos de 1 vez/semana', score: 0 },
    ]
  },
  {
    id: 'legumes', name: 'Legumbres',
    question: '¿Comés legumbres? (lentejas, porotos, garbanzos)',
    direction: 'positive',
    options: [
      { id: 'mepa5_a', title: '4+ veces por semana', score: 1 },
      { id: 'mepa5_b', title: '1 a 3 veces/semana', score: 0 },
      { id: 'mepa5_c', title: 'Casi nunca', score: 0 },
    ]
  },
  {
    id: 'whole_grains', name: 'Cereales integrales',
    question: '¿Elegís pan, pastas o cereales integrales?',
    direction: 'positive',
    options: [
      { id: 'mepa6_a', title: 'Siempre o casi siempre', score: 1 },
      { id: 'mepa6_b', title: 'A veces', score: 0 },
      { id: 'mepa6_c', title: 'Casi nunca', score: 0 },
    ]
  },
  {
    id: 'red_meat', name: 'Carnes rojas',
    question: '¿Cuántas veces por semana comés carne roja, fiambres o embutidos?',
    direction: 'inverse',
    options: [
      { id: 'mepa7_a', title: 'Menos de 3 veces/semana', score: 1 },
      { id: 'mepa7_b', title: '3 a 5 veces/semana', score: 0 },
      { id: 'mepa7_c', title: 'Casi todos los días', score: 0 },
    ]
  },
  {
    id: 'ultraprocessed', name: 'Ultraprocesados',
    question: '¿Con qué frecuencia comés comida rápida, dulces o facturas?',
    direction: 'inverse',
    options: [
      { id: 'mepa8_a', title: 'Menos de 1 vez/semana', score: 1 },
      { id: 'mepa8_b', title: '2 a 4 veces/semana', score: 0 },
      { id: 'mepa8_c', title: 'Casi todos los días', score: 0 },
    ]
  },
];

// MEPA-Express → CVH Diet Points bridge
export function mepaToCVH(score: number): number {
  if (score >= 8) return 100;
  if (score >= 6) return 80;
  if (score >= 4) return 50;
  if (score >= 2) return 25;
  return 0;
}

// ── LE8 QUICK METRICS ──

export interface LE8Metric {
  id: string;
  name: string;
  loinc: string;
  loincDisplay: string;
  category: 'survey' | 'vital-signs';
  question: string;
  options: { id: string; title: string; points: number }[]; // -1 = unknown
}

export const LE8_METRICS: LE8Metric[] = [
  // Metric 1 (Diet) is pre-filled from MEPA-Express - NOT asked again
  {
    id: 'physical_activity', name: 'Actividad física',
    loinc: '68516-4', loincDisplay: 'Moderate-vigorous PA days/wk',
    category: 'survey',
    question: '¿Cuántos minutos de actividad física hacés por semana? (caminar, bici, baile)',
    options: [
      { id: 'le8_pa_a', title: '150 min o más/semana', points: 100 },
      { id: 'le8_pa_b', title: '75 a 149 min/semana', points: 80 },
      { id: 'le8_pa_c', title: 'Menos de 75 min/sem', points: 40 },
    ]
  },
  {
    id: 'nicotine', name: 'Nicotina',
    loinc: '39240-7', loincDisplay: 'Tobacco use status',
    category: 'survey',
    question: '¿Fumás, vapeás, o estás expuesta a humo de tabaco?',
    options: [
      { id: 'le8_nic_a', title: 'Nunca fumé ni vapeo', points: 100 },
      { id: 'le8_nic_b', title: 'Dejé hace más de 1 año', points: 50 },
      { id: 'le8_nic_c', title: 'Fumo o vapeo actualmente', points: 0 },
    ]
  },
  {
    id: 'sleep', name: 'Sueño',
    loinc: '93832-4', loincDisplay: 'Sleep duration',
    category: 'survey',
    question: '¿Cuántas horas dormís por noche en promedio?',
    options: [
      { id: 'le8_sl_a', title: '7 a 9 horas', points: 100 },
      { id: 'le8_sl_b', title: '6 a 7 horas', points: 70 },
      { id: 'le8_sl_c', title: 'Menos de 6 horas', points: 20 },
    ]
  },
  {
    id: 'bmi', name: 'IMC (peso)',
    loinc: '39156-5', loincDisplay: 'Body mass index',
    category: 'vital-signs',
    question: '¿Conocés tu peso y tu Índice de Masa Corporal?',
    options: [
      { id: 'le8_bmi_a', title: 'Peso saludable (IMC < 25)', points: 100 },
      { id: 'le8_bmi_b', title: 'Sobrepeso (IMC 25-30)', points: 70 },
      { id: 'le8_bmi_c', title: 'No conozco mi IMC', points: -1 },
    ]
  },
  {
    id: 'blood_lipids', name: 'Colesterol',
    loinc: '13457-7', loincDisplay: 'Non-HDL Cholesterol',
    category: 'vital-signs',
    question: '¿Te hiciste un análisis de colesterol en el último año?',
    options: [
      { id: 'le8_lip_a', title: 'Sí, me dijeron que está bien', points: 80 },
      { id: 'le8_lip_b', title: 'Sí, está alto o tomo medicación', points: 35 },
      { id: 'le8_lip_c', title: 'No me hice análisis', points: -1 },
    ]
  },
  {
    id: 'blood_glucose', name: 'Glucosa',
    loinc: '4548-4', loincDisplay: 'Hemoglobin A1c',
    category: 'vital-signs',
    question: '¿Conocés tu nivel de azúcar en sangre?',
    options: [
      { id: 'le8_glu_a', title: 'Normal', points: 100 },
      { id: 'le8_glu_b', title: 'Prediabetes o diabetes', points: 30 },
      { id: 'le8_glu_c', title: 'No lo sé', points: -1 },
    ]
  },
  {
    id: 'blood_pressure', name: 'Presión arterial',
    loinc: '85354-9', loincDisplay: 'Blood pressure panel',
    category: 'vital-signs',
    question: '¿Te tomaron la presión recientemente?',
    options: [
      { id: 'le8_bp_a', title: 'Sí, debajo de 120/80', points: 100 },
      { id: 'le8_bp_b', title: 'Sí, alta o con medicación', points: 30 },
      { id: 'le8_bp_c', title: 'No lo sé', points: -1 },
    ]
  },
];

// Life Stage Weight Multipliers
export const LIFE_STAGE_WEIGHTS: Record<string, Record<string, number>> = {
  A: { diet: 1, physical_activity: 1.25, nicotine: 1, sleep: 1.25, bmi: 1, blood_lipids: 1, blood_glucose: 1, blood_pressure: 1 },
  B: { diet: 1, physical_activity: 1, nicotine: 1.25, sleep: 1, bmi: 1, blood_lipids: 1, blood_glucose: 1.30, blood_pressure: 1 },
  C: { diet: 1, physical_activity: 1, nicotine: 1, sleep: 1, bmi: 1, blood_lipids: 1.30, blood_glucose: 1, blood_pressure: 1.20 },
  D: { diet: 1, physical_activity: 1, nicotine: 1, sleep: 1, bmi: 1.20, blood_lipids: 1, blood_glucose: 1, blood_pressure: 1.20 },
};

// Compute LE8 composite score with life-stage weights
export function computeLE8Score(
  dietPts: number,
  le8Answers: { metricId: string; points: number | null }[],
  group: string
): { score: number; gapCount: number } {
  const weights = LIFE_STAGE_WEIGHTS[group] || LIFE_STAGE_WEIGHTS['A'];

  let weightedSum = dietPts * (weights.diet || 1);
  let count = 1; // diet always counted
  let gapCount = 0;

  for (const a of le8Answers) {
    if (a.points === null) {
      gapCount++;
      continue;
    }
    const w = weights[a.metricId] || 1;
    weightedSum += a.points * w;
    count++;
  }

  const score = count > 0 ? Math.round(weightedSum / count) : 0;
  return { score, gapCount };
}
