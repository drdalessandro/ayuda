// ============================================================
// Session Management - DynamoDB
// Stores conversation state per phone number
// ============================================================

import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, GetCommand, PutCommand } from '@aws-sdk/lib-dynamodb';

const TABLE_NAME = process.env.DYNAMODB_TABLE || 'epa-wa-sessions';
const SESSION_TTL_SECONDS = 1800; // 30 minutes

const ddb = DynamoDBDocumentClient.from(
  new DynamoDBClient({ region: process.env.AWS_REGION || 'us-east-1' })
);

// ── Session State Definition ──
// This is the "memory" of the conversation - everything we know so far
export interface Session {
  phone: string;                 // WhatsApp phone number (partition key)
  state: string;                 // Current state in the state machine
  createdAt: string;             // ISO timestamp
  updatedAt: string;             // ISO timestamp
  expiresAt: number;             // DynamoDB TTL (epoch seconds)

  // Data accumulated during conversation
  lifeStage?: {
    ageRange?: string;           // "18-27" | "28-44" | "45-65" | "66+"
    group?: 'A' | 'B' | 'C' | 'D';
    contextTag?: string;         // "student" | "planning" | "menopause" etc
  };

  mepaExpress?: {
    answers: { itemId: string; chosenValue: number; score: number }[];
    totalScore?: number;
    cvhDietPoints?: number;
  };

  le8Quick?: {
    answers: { metricId: string; points: number | null; isUnknown: boolean }[];
    compositeScore?: number;
    gapCount?: number;
  };

  // Name (asked after life stage classification)
  userName?: string;
}

// ── Get Session (or create new one) ──
export async function getSession(phone: string): Promise<Session> {
  try {
    const result = await ddb.send(new GetCommand({
      TableName: TABLE_NAME,
      Key: { phone }
    }));

    if (result.Item) {
      return result.Item as Session;
    }
  } catch (error) {
    console.error('DynamoDB get error:', error);
  }

  // New session - start at WELCOME state
  const now = new Date().toISOString();
  return {
    phone,
    state: 'WELCOME',
    createdAt: now,
    updatedAt: now,
    expiresAt: Math.floor(Date.now() / 1000) + SESSION_TTL_SECONDS,
    mepaExpress: { answers: [] },
    le8Quick: { answers: [] },
  };
}

// ── Save Session ──
export async function saveSession(session: Session): Promise<void> {
  session.updatedAt = new Date().toISOString();
  session.expiresAt = Math.floor(Date.now() / 1000) + SESSION_TTL_SECONDS;

  try {
    await ddb.send(new PutCommand({
      TableName: TABLE_NAME,
      Item: session
    }));
  } catch (error) {
    console.error('DynamoDB put error:', error);
    throw error;
  }
}
