// ============================================================
// State Machine - Controls the conversation flow
// Each state returns messages to send and advances the state
// ============================================================

import { Session } from './session';
import { WAMessage } from './whatsapp';
import {
  LIFE_STAGE_Q1_LIST, LIFE_STAGE_Q2, resolveGroup, GROUP_MESSAGES,
  MEPA_ITEMS, mepaToCVH,
  LE8_METRICS, computeLE8Score
} from './questions';
import { submitToMedplum } from './fhir-builder';

interface UserInput {
  phone: string;
  text: string;
  buttonId?: string;
}

// ── State Machine ──
export async function processState(session: Session, input: UserInput): Promise<WAMessage[]> {
  const messages: WAMessage[] = [];
  const id = input.buttonId || input.text.toLowerCase().trim();

  switch (session.state) {

    // ────────────────────────────────────
    // WELCOME - First contact
    // ────────────────────────────────────
    case 'WELCOME': {
      messages.push({
        type: 'text',
        text: 'Hola, soy *EPA Bienestar* — tu compañera de salud cardiovascular. 💚\n\n¿Sabías que 1 de cada 3 mujeres en Argentina tiene riesgo cardiovascular, pero la mayoría no lo sabe?'
      });
      messages.push({
        type: 'text',
        text: 'Voy a hacerte unas preguntas rápidas para conocerte y evaluar la salud de tu corazón. Toma menos de 5 minutos.'
      });
      messages.push({
        type: 'list',
        header: 'Empecemos',
        body: LIFE_STAGE_Q1_LIST.body,
        buttonText: LIFE_STAGE_Q1_LIST.buttonText,
        sections: LIFE_STAGE_Q1_LIST.sections,
      });
      session.state = 'LIFE_STAGE_Q1';
      break;
    }

    // ────────────────────────────────────
    // LIFE STAGE Q1 - Age range
    // ────────────────────────────────────
    case 'LIFE_STAGE_Q1': {
      const ageRange = id.replace('age_', ''); // "18-27", "28-44", "45-65", "66+"
      if (!session.lifeStage) session.lifeStage = {};
      session.lifeStage.ageRange = ageRange;

      const q2 = LIFE_STAGE_Q2[ageRange];
      if (q2) {
        messages.push({
          type: 'buttons',
          body: q2.body,
          buttons: q2.buttons,
        });
        session.state = 'LIFE_STAGE_Q2';
      }
      break;
    }

    // ────────────────────────────────────
    // LIFE STAGE Q2 - Context
    // ────────────────────────────────────
    case 'LIFE_STAGE_Q2': {
      const contextTag = id.replace('ctx_', '');
      const ageRange = session.lifeStage?.ageRange || '18-27';
      const group = resolveGroup(ageRange, id);

      session.lifeStage!.contextTag = contextTag;
      session.lifeStage!.group = group;

      const gm = GROUP_MESSAGES[group];
      messages.push({
        type: 'text',
        text: `*Grupo ${group}: ${gm.focus}*\n\n${gm.welcome}`
      });

      // Ask for name
      messages.push({
        type: 'text',
        text: '¿Cómo te llamo? (escribí tu nombre)'
      });
      session.state = 'ASK_NAME';
      break;
    }

    // ────────────────────────────────────
    // ASK NAME - Free text input
    // ────────────────────────────────────
    case 'ASK_NAME': {
      session.userName = input.text.trim();
      messages.push({
        type: 'text',
        text: `Encantada, *${session.userName}*! 💚\n\nAhora vamos a evaluar tu alimentación con *8 preguntas rápidas* basadas en el patrón mediterráneo (MEPA).`
      });

      // Start MEPA-Express Q1
      const item = MEPA_ITEMS[0];
      messages.push({
        type: 'buttons',
        header: `1/8 — ${item.name}`,
        body: item.question,
        footer: item.direction === 'inverse' ? 'Menos es mejor' : 'Más es mejor',
        buttons: item.options.map(o => ({ id: o.id, title: o.title })),
      });
      session.state = 'MEPA_Q1';
      break;
    }

    // ────────────────────────────────────
    // MEPA Q1-Q8 - Diet assessment
    // ────────────────────────────────────
    case 'MEPA_Q1': case 'MEPA_Q2': case 'MEPA_Q3': case 'MEPA_Q4':
    case 'MEPA_Q5': case 'MEPA_Q6': case 'MEPA_Q7': case 'MEPA_Q8': {
      const qNum = parseInt(session.state.replace('MEPA_Q', '')) - 1;
      const currentItem = MEPA_ITEMS[qNum];
      const chosen = currentItem.options.find(o => o.id === id);

      if (!session.mepaExpress) session.mepaExpress = { answers: [] };
      session.mepaExpress.answers.push({
        itemId: currentItem.id,
        chosenValue: chosen ? currentItem.options.indexOf(chosen) : 0,
        score: chosen?.score ?? 0,
      });

      const nextQ = qNum + 1;
      if (nextQ < MEPA_ITEMS.length) {
        // Next MEPA question
        const nextItem = MEPA_ITEMS[nextQ];
        messages.push({
          type: 'buttons',
          header: `${nextQ + 1}/8 — ${nextItem.name}`,
          body: nextItem.question,
          footer: nextItem.direction === 'inverse' ? 'Menos es mejor' : 'Más es mejor',
          buttons: nextItem.options.map(o => ({ id: o.id, title: o.title })),
        });
        session.state = `MEPA_Q${nextQ + 1}`;
      } else {
        // MEPA complete - calculate score
        const total = session.mepaExpress.answers.reduce((s, a) => s + a.score, 0);
        const cvhPts = mepaToCVH(total);
        session.mepaExpress.totalScore = total;
        session.mepaExpress.cvhDietPoints = cvhPts;

        const label = cvhPts >= 80 ? 'Muy buena' : cvhPts >= 50 ? 'Moderada' : 'A mejorar';
        messages.push({
          type: 'text',
          text: `*Tu dieta: ${total}/8* (${label})\nPuntos CVH dieta: *${cvhPts}/100*\n\nAhora vamos a medir tus *8 métricas de salud cardiovascular* (Life's Essential 8).`
        });

        // Start LE8 Quick
        const le8q = LE8_METRICS[0];
        messages.push({
          type: 'buttons',
          header: `2/8 — ${le8q.name}`,
          body: le8q.question,
          footer: 'Tu dieta ya fue evaluada (1/8)',
          buttons: le8q.options.map(o => ({ id: o.id, title: o.title })),
        });
        session.state = 'LE8_Q1';
      }
      break;
    }

    // ────────────────────────────────────
    // LE8 Q1-Q7 - Health metrics
    // ────────────────────────────────────
    case 'LE8_Q1': case 'LE8_Q2': case 'LE8_Q3': case 'LE8_Q4':
    case 'LE8_Q5': case 'LE8_Q6': case 'LE8_Q7': {
      const qNum = parseInt(session.state.replace('LE8_Q', '')) - 1;
      const metric = LE8_METRICS[qNum];
      const chosen = metric.options.find(o => o.id === id);
      const points = chosen?.points ?? 0;
      const isUnknown = points === -1;

      if (!session.le8Quick) session.le8Quick = { answers: [] };
      session.le8Quick.answers.push({
        metricId: metric.id,
        points: isUnknown ? null : points,
        isUnknown,
      });

      // If unknown, send reassurance
      if (isUnknown) {
        messages.push({
          type: 'text',
          text: `No te preocupes — esto nos indica que necesitamos medir tu *${metric.name.toLowerCase()}*. Lo anotamos para tu orden de estudios.`
        });
      }

      const nextQ = qNum + 1;
      if (nextQ < LE8_METRICS.length) {
        const nextMetric = LE8_METRICS[nextQ];
        const metricNum = nextQ + 2; // +2 because diet is metric 1
        messages.push({
          type: 'buttons',
          header: `${metricNum}/8 — ${nextMetric.name}`,
          body: nextMetric.question,
          buttons: nextMetric.options.map(o => ({ id: o.id, title: o.title })),
        });
        session.state = `LE8_Q${nextQ + 1}`;
      } else {
        // LE8 complete - calculate score and submit to Medplum
        session.state = 'RESULTS';

        const dietPts = session.mepaExpress?.cvhDietPoints || 0;
        const group = session.lifeStage?.group || 'A';
        const le8Answers = session.le8Quick.answers.map(a => ({
          metricId: a.metricId,
          points: a.points,
        }));

        const { score, gapCount } = computeLE8Score(dietPts, le8Answers, group);
        session.le8Quick.compositeScore = score;
        session.le8Quick.gapCount = gapCount;

        const cvhLabel = score >= 80 ? 'Alta 💚' : score >= 50 ? 'Moderada 💛' : 'Baja — necesitás atención 🔴';

        messages.push({
          type: 'text',
          text: `*${session.userName}, tu resultado LE8:*\n\n🫀 Score: *${score}/100*\nSalud cardiovascular: *${cvhLabel}*\n📊 Grupo ${group} (pesos ajustados)\n${gapCount > 0 ? `\n⚠️ ${gapCount} métricas sin datos — necesitás estudios` : '\n✅ Todas las métricas evaluadas'}`
        });

        // Submit to Medplum FHIR R4
        try {
          const result = await submitToMedplum(session);
          messages.push({
            type: 'text',
            text: `✅ Tu evaluación fue guardada en tu expediente digital (FHIR R4).\n\nPodés ver tu resultado completo en:\n👉 *mujer.epa-bienestar.com.ar/mi-le8*`
          });
        } catch (err) {
          console.error('Medplum submission error:', err);
          messages.push({
            type: 'text',
            text: '✅ Tu evaluación fue registrada. Te enviaremos tu resultado completo en breve.'
          });
        }

        // Offer next steps
        messages.push({
          type: 'buttons',
          body: '¿Qué te gustaría hacer ahora?',
          buttons: [
            { id: 'next_plan', title: 'Ver Plan Bienestar 100D' },
            { id: 'next_cardio', title: 'Hablar con cardióloga' },
            { id: 'next_later', title: 'Lo veo después' },
          ],
        });
        session.state = 'NEXT_STEPS';
      }
      break;
    }

    // ────────────────────────────────────
    // NEXT STEPS - Post-results actions
    // ────────────────────────────────────
    case 'NEXT_STEPS': {
      if (id === 'next_plan') {
        messages.push({
          type: 'text',
          text: `*${session.userName}*, tu Plan Bienestar 100 Días ya está personalizado.\n\n👉 mujer.epa-bienestar.com.ar/mi-plan\n\nTe voy a escribir cada semana con tu progreso. 💚`
        });
      } else if (id === 'next_cardio') {
        messages.push({
          type: 'text',
          text: `Vamos a conectarte con una cardióloga de la red FAC especializada en salud cardiovascular femenina. Te va a contactar en las próximas 24-48 horas.\n\n🏥 Red FAC: 38 sociedades, 2000+ cardiólogos`
        });
      } else {
        messages.push({
          type: 'text',
          text: `Sin problema, *${session.userName}*. Tu evaluación queda guardada.\n\nTe voy a escribir mañana para recordarte. Tu corazón puede esperar un día — pero no mucho más. 💚`
        });
      }
      session.state = 'END';
      break;
    }

    // ────────────────────────────────────
    // END or unknown state - restart
    // ────────────────────────────────────
    default: {
      messages.push({
        type: 'text',
        text: 'Hola! Para iniciar una nueva evaluación cardiovascular, escribí *hola*.'
      });
      session.state = 'WELCOME';
      break;
    }
  }

  return messages;
}
