// ============================================================
// WhatsApp Business API - Message Sender
// Sends text, buttons, and list messages
// ============================================================

const WA_PHONE_NUMBER_ID = process.env.WA_PHONE_NUMBER_ID!;
const WA_ACCESS_TOKEN = process.env.WA_ACCESS_TOKEN!;
const WA_API_URL = `https://graph.facebook.com/v19.0/${WA_PHONE_NUMBER_ID}/messages`;

// ── Message Types ──

export interface TextMessage {
  type: 'text';
  text: string;
}

export interface ButtonMessage {
  type: 'buttons';
  header?: string;
  body: string;
  footer?: string;
  buttons: { id: string; title: string }[]; // Max 3 buttons
}

export interface ListMessage {
  type: 'list';
  header?: string;
  body: string;
  footer?: string;
  buttonText: string;
  sections: {
    title: string;
    rows: { id: string; title: string; description?: string }[];
  }[];
}

export interface ImageMessage {
  type: 'image';
  imageUrl: string;
  caption?: string;
}

export type WAMessage = TextMessage | ButtonMessage | ListMessage | ImageMessage;

// ── Send Message ──
export async function sendWhatsAppMessage(phone: string, message: WAMessage): Promise<void> {
  let payload: any = {
    messaging_product: 'whatsapp',
    recipient_type: 'individual',
    to: phone,
  };

  switch (message.type) {
    case 'text':
      payload.type = 'text';
      payload.text = { preview_url: false, body: message.text };
      break;

    case 'buttons':
      payload.type = 'interactive';
      payload.interactive = {
        type: 'button',
        ...(message.header ? { header: { type: 'text', text: message.header } } : {}),
        body: { text: message.body },
        ...(message.footer ? { footer: { text: message.footer } } : {}),
        action: {
          buttons: message.buttons.map(b => ({
            type: 'reply',
            reply: { id: b.id, title: b.title }
          }))
        }
      };
      break;

    case 'list':
      payload.type = 'interactive';
      payload.interactive = {
        type: 'list',
        ...(message.header ? { header: { type: 'text', text: message.header } } : {}),
        body: { text: message.body },
        ...(message.footer ? { footer: { text: message.footer } } : {}),
        action: {
          button: message.buttonText,
          sections: message.sections
        }
      };
      break;

    case 'image':
      payload.type = 'image';
      payload.image = {
        link: message.imageUrl,
        ...(message.caption ? { caption: message.caption } : {})
      };
      break;
  }

  try {
    const response = await fetch(WA_API_URL, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${WA_ACCESS_TOKEN}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      const error = await response.text();
      console.error(`WhatsApp API error (${response.status}):`, error);
    }
  } catch (error) {
    console.error('WhatsApp send error:', error);
  }
}
